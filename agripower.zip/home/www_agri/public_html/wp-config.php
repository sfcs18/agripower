<?php
/**
 * WordPress の基本設定
 *
 * このファイルは、インストール時に wp-config.php 作成ウィザードが利用します。
 * ウィザードを介さずにこのファイルを "wp-config.php" という名前でコピーして
 * 直接編集して値を入力してもかまいません。
 *
 * このファイルは、以下の設定を含みます。
 *
 * * MySQL 設定
 * * 秘密鍵
 * * データベーステーブル接頭辞
 * * ABSPATH
 *
 * @link http://wpdocs.osdn.jp/wp-config.php_%E3%81%AE%E7%B7%A8%E9%9B%86
 *
 * @package WordPress
 */

// 注意:
// Windows の "メモ帳" でこのファイルを編集しないでください !
// 問題なく使えるテキストエディタ
// (http://wpdocs.osdn.jp/%E7%94%A8%E8%AA%9E%E9%9B%86#.E3.83.86.E3.82.AD.E3.82.B9.E3.83.88.E3.82.A8.E3.83.87.E3.82.A3.E3.82.BF 参照)
// を使用し、必ず UTF-8 の BOM なし (UTF-8N) で保存してください。

// ** MySQL 設定 - この情報はホスティング先から入手してください。 ** //
/** WordPress のためのデータベース名 */
define('WP_CACHE', true);
define( 'WPCACHEHOME', '/home/www_agri/public_html/wp-content/plugins/wp-super-cache/' );
define('DB_NAME', 'agriwp');

/** MySQL データベースのユーザー名 */
define('DB_USER', 'agridb');

/** MySQL データベースのパスワード */
define('DB_PASSWORD', 'zV7jCQcd');

/** MySQL のホスト名 */
define('DB_HOST', 'localhost');

/** データベースのテーブルを作成する際のデータベースの文字セット */
define('DB_CHARSET', 'utf8mb4');

/** データベースの照合順序 (ほとんどの場合変更する必要はありません) */
define('DB_COLLATE', '');

/**#@+
 * 認証用ユニークキー
 *
 * それぞれを異なるユニーク (一意) な文字列に変更してください。
 * {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org の秘密鍵サービス} で自動生成することもできます。
 * 後でいつでも変更して、既存のすべての cookie を無効にできます。これにより、すべてのユーザーを強制的に再ログインさせることになります。
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'Z80i^YEEo c=)C8D?qxy|@%3At~=6%r^6l5<VrKp7oyF0)b8PmWA?}lX;-#N5{r+');
define('SECURE_AUTH_KEY',  'NpEm)KoX?/f50p@q5cmZ.NJUdVrkR`FV4&Id}+O38`P/+#Q<h8byCF~F[, 2Dl+p');
define('LOGGED_IN_KEY',    '>O|Z3U.z3HnJuzAb~Na)Cop!GTx6&rn1|aZ 7#VC;AE?xo9_Eu!izH+P[Dyh^^/G');
define('NONCE_KEY',        'X8+OP)C6Y6wZtmbfV2EYHVi,O47|i$Jw5|u$tQ/S;%9|swo?d}ANbL1q^Xa}LFF:');
define('AUTH_SALT',        'qSzm&fLx!`KpP@LX7g6=)``]p?)if@pZ<N40{|0|x)Kf<r+[c>Ah|FAqE}B@Rr$B');
define('SECURE_AUTH_SALT', '?4$Kb?l[Ps:{/PM+6m7)eYo E.U_. _ i$yB~J(2:asnpocGlKazi_QB:+nJZ&93');
define('LOGGED_IN_SALT',   'Fg{}v~wKU*@?7:Gm!5WxC}xk3h9U)ofTG!qPHC7fT=] >Fawx_O!s/H@f-%@b//]');
define('NONCE_SALT',       '+.`Zk8!b:J_HUeHV?((s_p{q2kCFh`vK6Ky*XSq$nIKV,|(Of^s eax7(:7(X7c:');

/**#@-*/

/**
 * WordPress データベーステーブルの接頭辞
 *
 * それぞれにユニーク (一意) な接頭辞を与えることで一つのデータベースに複数の WordPress を
 * インストールすることができます。半角英数字と下線のみを使用してください。
 */
$table_prefix  = 'wp_';

/**
 * 開発者へ: WordPress デバッグモード
 *
 * この値を true にすると、開発中に注意 (notice) を表示します。
 * テーマおよびプラグインの開発者には、その開発環境においてこの WP_DEBUG を使用することを強く推奨します。
 *
 * その他のデバッグに利用できる定数については Codex をご覧ください。
 *
 * @link http://wpdocs.osdn.jp/WordPress%E3%81%A7%E3%81%AE%E3%83%87%E3%83%90%E3%83%83%E3%82%B0
 */
define('WP_DEBUG', false);

/* 編集が必要なのはここまでです ! WordPress でブログをお楽しみください。 */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
define('FS_METHOD','direct');
